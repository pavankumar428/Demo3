from flask import Flask, request
from flask_restful import Resource, Api

# Intializes the flask and restful framework

app = Flask(__name__)
api = Api(app)

# Holds people data
Data = []


class User(Resource):
    # GET request
    def get(self):
        return Data

    # POST request
    def post(self):
        # Check if data Exists in the array, save only when it doesn't exist
        if request.json['name'] in Data:
            return 'User already exists, please check.'
        else:
            # Add new data into the data
            Data.append(request.json['name'])
            return 'User saved'


class DeleteUser(Resource):
    # DELETE request
    def delete(self, name):
        if name in Data:
            Data.remove(name)
            return 'User deleted successfully'
        else:
            return 'User not found'


# Defines the Route and which class to use
api.add_resource(User, '/users')
api.add_resource(DeleteUser, '/users/<string:name>')

if __name__ == '__main__':
    app.run(debug=True)
